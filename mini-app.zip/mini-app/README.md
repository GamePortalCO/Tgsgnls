# Trading Signals Mini App

Telegram Mini App для просмотра торговых сигналов.

## Деплой на Vercel (бесплатно)

### 1. Создай репозиторий на GitHub

1. Зайди на github.com и создай новый репозиторий
2. Загрузи туда папку `mini-app`

### 2. Подключи Vercel

1. Зайди на [vercel.com](https://vercel.com)
2. Нажми "Add New Project"
3. Импортируй репозиторий с GitHub
4. В настройках добавь Environment Variables:
   - `VITE_SUPABASE_URL` = твой Supabase URL
   - `VITE_SUPABASE_ANON_KEY` = твой Supabase anon key (публичный)
5. Нажми Deploy

### 3. Получи URL

После деплоя Vercel даст URL типа:
```
https://trading-signals-xxx.vercel.app
```

### 4. Настрой бота

1. В n8n в ноде "Send App" замени `https://example.com` на URL от Vercel
2. В @BotFather:
   ```
   /mybots → твой бот → Bot Settings → Menu Button → Configure menu button
   ```
   Вставь URL от Vercel

## Локальная разработка

```bash
# Установка
npm install

# Создай .env файл
cp .env.example .env
# Заполни VITE_SUPABASE_URL и VITE_SUPABASE_ANON_KEY

# Запуск
npm run dev
```

## Структура

```
mini-app/
├── src/
│   ├── App.tsx          # Главный компонент с навигацией
│   ├── components/
│   │   ├── SignalCard.tsx   # Карточка сигнала
│   │   ├── EventCard.tsx    # Карточка события
│   │   ├── BottomNav.tsx    # Нижняя навигация
│   │   ├── Tabs.tsx         # Табы фильтров
│   │   └── UI.tsx           # Базовые компоненты
│   ├── hooks/           # React хуки
│   ├── lib/
│   │   └── supabase.ts  # API клиент
│   └── types/           # TypeScript типы
├── .env.example
├── package.json
└── vite.config.ts
```

## Функции

- 📊 Просмотр активных сигналов
- 🔔 Подписка на уведомления о ценах
- 📅 Календарь экономических событий
- 🎨 Темная тема в стиле Telegram
